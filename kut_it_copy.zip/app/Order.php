<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
//    public function bookings(){
//        return $this->belongsTo(Booking::class,'booking_id');
//    }
//
//    public function service(){
//        return $this->belongsTo(Service::class,'service_id');
//    }
}
